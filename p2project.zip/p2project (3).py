
# coding: utf-8

# ## Titanic Data Analysis
# 
# Through this notebook we shall analyze what factors made people more likely to survive. I personally believe it has to do with gender, age and class. I will further break This question down and we can ask "was gender and age a factor in survival" as made popular in the Titanic movie "women and children first". I also want to answer "Did adults who have a higher social class survive more than people in lower social classes?" we would conduct this analysis by means of grouping people by both cabin and people who survived.

# ###### Load Data from CSV file

# In[1]:

#Imports
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns 

#Read in csv file 

filename = r'C:\\Users\\Krishna\\Desktop\\udacity projects\\p2\\p2 project\\titanic-data.csv'
titanicdata = pd.read_csv(filename)

#check to see if the data has loaded properly
titanicdata.head()


# ## Let's see what the data looks like before cleaning it up

# In[157]:

#group by age and count the number of people 
get_ipython().magic(u'pylab inline')

y = titanicdata.groupby(['Age'])['PassengerId'].count()
N = len(y)
x = range(N)
plt.bar(x, y)
plt.ylabel("passenger counts")
plt.xlabel("Ages")
plt.title("distribution of ages")



# Here we see the distribution of ages on the ship. We haven't cleaned the data though so this is why I want to say that we are getting 0 values.

# In[25]:

#output a piechart with the distribution of classes
figure(1, figsize=(6,6))
ax = axes([0.1, 0.1, 0.8, 0.8])
labels = 'First Class', 'Second Class', 'Third Class'
colors = ['yellowgreen', 'gold', 'lightskyblue']
f = titanicdata.groupby(['Pclass'])['PassengerId'].count()
pie(f, autopct='%1.1f%%', startangle=90, labels = labels, colors = colors)


# We see the makeup of the data according to class here. 24.2% of people were in first class, 20.7% of people were in second class and the majority of people , 55.1%, on the ship were in third class.

# ## Fixing Data Types

# looking at the raw data file itself there are several instances where age is blank or it is half a number so what I want to do here is remove instances where the age is blank because it won't give me any relevant information. and with the half numbers i want to round it up or down to the nearest whole number.

# ##### Removing records with blank age

# In[26]:

#check to see length of the titanic data file
len(titanicdata)


# In[27]:

titanicdata = titanicdata[titanicdata.Age.notnull()]
len(titanicdata)


# ##### Rounding age values

# In[28]:

#loop through each value in the age column and then apply the round function
for x in titanicdata.Age:
    x.round

#print titanicdata.head()

#check to see if length is the same after cleanup step 1
len(titanicdata)

#titanicdata = titanicdata.loc([titanicdata.Age]).apply(np.round) gave me some key error hm..


# ## Data exploration

# here are some general descriptions of the data

# In[29]:

titanicdata.describe()


# we see that on average only 40% of the people survived (from this dataset) and the average age of the person aboard the ship was 29.69 

# ##### Grouping data by survived, gender and age
# Here we want to see the number of people that survived, what the gender was, and how old they were 

# In[30]:

#Remove all instances with people who didn't live
groupeddata = titanicdata[titanicdata.Survived != 0] 
#print groupeddata


# In[31]:

#group data by people who survived

totalsurvivors = groupeddata.groupby(['Survived'])['PassengerId'].count()
print totalsurvivors


# After removing the number of people who didn't survive we see that the number of people who survived was 290. Doing a spot check we see that 290/714 (total number of records after the clean up) we get a value of .406 this is equal to the mean that we saw in the previous step. I want to go ahead and create a plot to see how the 290 survivors were distributed across the the 3 classes. And at first I thought let's do a scatter plot.

# In[33]:

#%pylab inline 

x = groupeddata.groupby(['Pclass'])['PassengerId'].count()
y = np.arange(len(x))
yaxis = ('Class 1','Class 2', 'Class 3')
plt.yticks(y, yaxis)
plt.scatter(x,y, alpha = .5)
plt.xlabel('Number of Survivors')
plt.ylabel('Class')
plt.title('Number of total survivors according to class')
plt.show()


# Alright, so this wasn't quite the plot I was hoping to see, but seeing as how I grouped the passengers both by class and the Passenger ID and counted the number of people, this makes sense. But this plot is a little hard to read and doesn't quite break down the survivors into categories such as children, men and women. So let's go ahead and take a look at that in order to see if class and gender was really a factor in survival. 

# #### Probability of survival by gender

# In[74]:

survivalgendermean = titanicdata.groupby(['Sex'])['Survived'].mean()
print survivalgendermean


# In[89]:

N = len(survivalgendermean)
x = range(N)
plt.bar(x, survivalgendermean, align = 'center')
plt.ylabel("probability of survival")
plt.title("survival rate of gender")
plt.xticks(np.arange(N), ('Female', 'Male'))


# Here we see that there is a much greater probability of surviving the titanic if you were female as opposed to male.

# #### Probability of Survival by class

# In[77]:

survivalbyclass = titanicdata.groupby('Pclass')['Survived'].mean()
print survivalbyclass


# In[156]:

get_ipython().magic(u'pylab inline')

N = len(survivalbyclass)
x = range(N)
plt.bar(x, survivalbyclass, align = 'center')
plt.ylabel("probability of survival")
plt.title("survival rate by class")
plt.xticks(np.arange(N), ('First', 'Second', 'Third'))


# Also I wanted to see the probability of survival by class and if there was a greater chance to survive if you were in a higher class. The step ladder shape of the graph indicates just that.

# ### Probability of Survival by both Gender and Class

# In[90]:

survivalbyboth = titanicdata.groupby(['Pclass','Sex'])['Survived'].mean()
print survivalbyboth


# In[123]:

#separate males and females so that we can make 2 separate bars in the chart
get_ipython().magic(u'pylab inline')
survivingmales = titanicdata[titanicdata.Sex != 'female']
survivingmalesmean = survivingmales.groupby(['Pclass'])['Survived'].mean()
print survivingmalesmean
survivingfemales = titanicdata[titanicdata.Sex != 'male']
survivingfemalesmean = survivingfemales.groupby(['Pclass'])['Survived'].mean()
print survivingfemalesmean

ngroups = 3
index = np.arange(ngroups)
bar_width = .5 

rects1 = plt.bar(index, survivingfemalesmean,bar_width, color = 'b', label = 'Female')
rects2 = plt.bar(index+bar_width, survivingmalesmean,bar_width, color = 'g', label = 'Male')
plt.ylabel("probability of survival")
plt.title("survival rate by class and gender")
plt.xticks(index+ bar_width, ('First', 'Second', 'Third'))
plt.legend()


# Putting both our variables together in one graph we have the probability of survival given class and gender. we see that females were favored over males and also that class came into play here. First class was generally more favored than second and second class was generally more favored than third.

# #### count of people who survived vs count of people who died

# Here I include raw counts of the data of the number of people who survived and died because giving just the proportion would tell the likelihood of someone surviving and not whether they actually survived or not.

# In[125]:

numberofsurvived = titanicdata.groupby(['Pclass', 'Sex', 'Survived']).apply(len)
print numberofsurvived


# In[141]:

numberdead = titanicdata[titanicdata.Survived == 0]
numberdead = numberdead[numberdead.Sex != 'female']
numberdead = numberdead.groupby(['Pclass', 'Sex', 'Survived']).apply(len)
numberdeadmale = numberdead 
print numberdeadmale

numberdead = titanicdata[titanicdata.Survived == 0]
numberdead = numberdead[numberdead.Sex != 'male']
numberdead = numberdead.groupby(['Pclass', 'Sex', 'Survived']).apply(len)
numberdeadfemale = numberdead 
print numberdeadfemale



# In[143]:

numberalive = titanicdata[titanicdata.Survived != 0]
numberalive = numberalive[numberalive.Sex != 'female']
numberalive = numberalive.groupby(['Pclass', 'Sex', 'Survived']).apply(len)
numberalivemale = numberalive
print numberalivemale

numberalive = titanicdata[titanicdata.Survived != 0]
numberalive = numberalive[numberalive.Sex != 'male']
numberalive = numberalive.groupby(['Pclass', 'Sex', 'Survived']).apply(len)
numberalivefemale = numberalive
print numberalivefemale




# In[153]:

get_ipython().magic(u'pylab inline')

ngroups = 3
index = np.arange(ngroups)
bar_width = .5 

rects1 = plt.bar(index, numberdeadfemale, bar_width, color = 'b' ,label = 'female')
rects2 = plt.bar(index + bar_width, numberdeadmale, bar_width,color = 'g', label = 'male')

plt.ylabel("Number of people who died")
plt.title("Number of people who died by class and gender")
plt.xticks(index + bar_width , ('First', 'Second', 'Third'))
plt.legend()


# As expected there are most deaths within the third class than the second and more deaths within the second than the first.

# In[155]:

get_ipython().magic(u'pylab inline')

ngroups = 3
index = np.arange(ngroups)
bar_width = .5 

rects1 = plt.bar(index, numberalivefemale, bar_width, color = 'b' ,label = 'female')
rects2 = plt.bar(index + bar_width, numberalivemale, bar_width,color = 'g', label = 'male')

plt.ylabel("Number of people who survived")
plt.title("Number of people who survived by class and gender")
plt.xticks(index + bar_width , ('First', 'Second', 'Third'))
plt.legend()


# As expected once again there are more survivors in the first class than the second and more survivors in the second class than the third.

# In[34]:

#count total number of male and female survivors

totalsurvivorsbygender = groupeddata.groupby(['Sex'])['PassengerId'].count()
print totalsurvivorsbygender


# Breaking our survivors down by gender we see that 104 more females made it out than males. This is starting to support my Titanic movie theory of "Women and children first" but we need to do some further analysis and we also need to keep in mind that this entire data set is only a sample as there were 2229 total passengers on board.

# In[35]:

#count average, min, and max age of total survivors
survivordata  = groupeddata.groupby(['Survived'])['Age']
survivordata.describe()


# I got curious and wanted to see the average age of the survivor and here we see that the average survivor was in their late 20s but there was a pretty big standard deviation of roughly 15 years.

# In[36]:

#how many of the people who did survive were children(in this case < 18)

survivingchildren =  titanicdata[titanicdata.Survived != 0]
survivingchildren = survivingchildren[survivingchildren.Age < 18]
print len(survivingchildren)

#print survivingchildren


# I wanted to first break the survivors down into children and adults. Here I took the number of people that survived from the data and the I broke it down to only people who were under the age of 18. I got 61 survivors as a result.

# In[37]:

#how many of the children who survived were in upper middle and lower classes
kidsbyclass = survivingchildren.groupby(['Pclass'])['PassengerId'].count()
print kidsbyclass


# I then went ahead and broke down the 61 survivors by class and found that we had 11 first class children, 21 second class children, and 29 third class children

# In[38]:

get_ipython().magic(u'pylab inline')

yaxis = ('Class 1','Class 2', 'Class 3')
y_pos = np.arange(len(kidsbyclass))
plt.barh(y_pos, kidsbyclass, align='center', alpha=1)
plt.yticks(y_pos, yaxis)
plt.title("number of Children that survived according to class")
plt.xlabel('Number of Children')
plt.ylabel('Class')
plt.show()


# Since the scatter plot didn't work earlier, I wanted to represent the findings as a bar graph. I feel as though this is much easier to read. Mathematically if we take 61 survivors away from the total number of survivors, 290, we should get 229 survivors.

# In[39]:

#how many of the people who did survive were adults broken down by gender
survivingadults = titanicdata[titanicdata.Survived != 0]
#survivingadults = survivingadults - survivingchildren
survivingadults = survivingadults[survivingadults.Age >= 18]
print len(survivingadults) 


# In this step I do just that and find that there are 229 adult survivors ages 18 and up. I want to now further break down the data we have by gender and class again.

# In[40]:

#number of female adults so we can break them down by class in the next step
femaleadults = survivingadults[survivingadults.Sex != 'male']

#number of adults both male and female that survived
numberofadults = survivingadults.groupby(['Sex'])['PassengerId'].count()
print numberofadults


# I removed the male passengers and then grouped the number of female passengers by the categories 'Sex' and 'PassengerId' and then I counted the remaining records. I got 159 records of adult females that survived the titanic. I also got 70 adult males who survived. This record matches up with our total because 159+70+61 = 290

# In[41]:

femaleadultsbyclass = femaleadults.groupby(['Sex','Pclass'])['PassengerId'].count()
print femaleadultsbyclass


# I then further broke it down by class and this shows us that there were 75 females from first class, 56 females from second class and 28 females from third class. Doing a spot check 75+56+28 = 159. This data hints at the fact that rich females did have more of a chance to make it out alive.

# In[42]:

get_ipython().magic(u'pylab inline')

yaxis = ('Class 1','Class 2', 'Class 3')
y_pos = np.arange(len(femaleadultsbyclass))
plt.barh(y_pos, femaleadultsbyclass, align='center', alpha=1)
plt.yticks(y_pos, yaxis)
plt.title("number of female adults that survived according to class")
plt.xlabel('Number of female adults')
plt.ylabel('Class')
plt.show()


# Here I have graphed out by class the number female adults that survived. From this graph I can start to make inferences about the rest of the population. I am going to do the same process as before on the male population. Doing a spot check we should get 70 male adults because 290 - 61 - 159 = 70

# In[43]:

maleadults = survivingadults[survivingadults.Sex != 'female']


# In[44]:

maleadultsbyclass = maleadults.groupby(['Sex','Pclass'])['PassengerId'].count()
print maleadultsbyclass


# When I break the males down by class I see something interesting happening, there are almost as many 3rd class males who survived as there are first class males. This is interesting to see. With the female adults it was step ladder with class 1 having the most and class 2 having the second most and then class 3 having the least. So why then is it different for the male adults?

# In[45]:

get_ipython().magic(u'pylab inline')

yaxis = ('Class 1','Class 2', 'Class 3')
y_pos = np.arange(len(maleadultsbyclass))
plt.barh(y_pos, maleadultsbyclass, align='center', alpha=1)
plt.yticks(y_pos, yaxis)
plt.title("number of male adults that survived according to class")
plt.xlabel('Number of male adults')
plt.ylabel('Class')
plt.show()


# looking at this, the graph isn't the perfect step ladder like the previous graph. I have a theory and I think there are almost as many 3rd class males that survived as first because 3rd class included workers aboard the ship. When people were escaping to the life boats these workers would guide people to the boats and then commandeer the boats until help arrived and the entire boat survived. 

# ## Limitations of the dataset

# There are various limitations within this dataset and due to these limitations we are required to operate under big assumptions everywhere. For example the dataset is filled with missing values. The way in which we clean up the missing values adds potential for drawbacks to the analysis. For example say we fill in a missing value with a 0 when performing an analysis we will have various different issues when accessing the data if we go to compare the data. If we remove the missing values' instance entirely we are not only limiting our dataset even more but we might also be removing a field that might be important to us in a later analysis and in essence we could see this ripple effect happening across the data.  

# There are also limitations that arise with doing an analysis and making assumptions without doing a statistical z or t test. Since we have made assumptions only to one sample picked from the entire population, we can not apply the assumption back to the entire population. While the findings may work for the sample they might not work for the entire population set.

# The data set also does not distinguish between correlation and causation. While we found earlier that it was more likely for females in the first class to survive the Titanic, and it did match our sample this might not hold true when applied to the population. The data set also does not tell us to make any assumptions about the population in order to conduct our analysis.

# ## Conclusions

# Using the question that I proposed and doing analysis on the data my conclusions are as follows:
# <ol>
# 1.) The quote "women and children first" from the movie is somewhat accurate. 
# 2.) There are more women that survived than children and more children that survived than men
# 3.) From the sample that we analyzed we can say that the factor that made you most likely to survive was if you were a female in class 1
# 4.) The number of third class males and females were equal, It is my assumption that both males and females in this class were workers aboard the ship who commandeered life boats
# </ol>

#  

# References:
# http://stackoverflow.com/questions/18172851/deleting-dataframe-row-in-pandas-based-on-column-value
# http://stackoverflow.com/questions/19384532/how-to-count-number-of-rows-in-a-group-in-pandas-group-by-object
# https://pythonspot.com/en/matplotlib-bar-chart/
# http://matplotlib.org/examples/shapes_and_collections/scatter_demo.html
# http://matplotlib.org/examples/pylab_examples/barchart_demo.html

#  

# In[ ]:



